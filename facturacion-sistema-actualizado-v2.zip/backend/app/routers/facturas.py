from datetime import date
import calendar
from decimal import Decimal
from typing import List, Optional

from dateutil.relativedelta import relativedelta
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.core.security import decode_token, requerir_admin
from app.core.config import settings
from app.models.cliente import Cliente
from app.models.factura import Factura, FacturaItem, Cuota, EstadoFactura
from app.models.pago import Pago, Recibo
from app.schemas.factura import (
    FacturaCreate, FacturaUpdate, FacturaOut, FacturaItemCreate, CuotaManualUpdate,
    ReenganeCreate, ReenganeElegibilidadOut,
)
from app.services.numeracion import generar_numero_factura
from app.services.mora import actualizar_estado_mora_factura
from app.services.pdf_factura import generar_pdf_factura
from app.services.reenganche import calcular_elegibilidad, ejecutar_reenganche

router = APIRouter(prefix="/api/facturas", tags=["Facturación"], dependencies=[Depends(decode_token)])


def _siguiente_quincena(actual: date) -> date:
    """Avanza estrictamente al siguiente día 15 o 30 del calendario (nunca
    31; en meses con menos de 30 días —febrero— usa el último día real del
    mes en vez del 30). Así 'quincenal' respeta los días 15 y 30 reales,
    no un salto flotante de +15 días desde la fecha base."""
    ultimo_dia_mes = calendar.monthrange(actual.year, actual.month)[1]
    dia_fin_quincena = min(30, ultimo_dia_mes)
    if actual.day < dia_fin_quincena:
        return actual.replace(day=dia_fin_quincena)
    siguiente_mes = actual.replace(day=1) + relativedelta(months=1)
    return siguiente_mes.replace(day=15)


def _siguiente_vencimiento(base: date, numero: int, frecuencia: str) -> date:
    """Cada cuánto cae la próxima cuota según la frecuencia de pago.
    La cuota 1 siempre cae en 'base' (la fecha elegida al crear la factura);
    las siguientes se calculan a partir de ahí paso a paso, sin arrastrar
    error acumulado."""
    if numero <= 1:
        return base
    if frecuencia == "semanal":
        return base + relativedelta(weeks=numero - 1)
    if frecuencia == "quincenal":
        actual = base
        for _ in range(numero - 1):
            actual = _siguiente_quincena(actual)
        return actual
    return base + relativedelta(months=numero - 1)


def _recalcular_fechas_pendientes(factura: Factura, nueva_fecha_base: date, frecuencia: str) -> None:
    """Reancla el calendario de cuotas cuando la operadora fuerza/edita la
    fecha de pago (o cambia la frecuencia) SIN tocar montos ni cantidad de
    cuotas — ej. "el cliente se atrasó pero acordamos que ahora paga cada
    10 de mes en vez de cada 5". Las cuotas YA PAGADAS son historial y no
    se tocan (nunca se reescribe cuándo pagó algo). A partir de la primera
    cuota todavía pendiente, se recalculan en cadena mes a mes (o semana/
    quincena a quincena) desde 'nueva_fecha_base', con el mismo cálculo
    limpio de _siguiente_vencimiento (sin arrastrar error acumulado ni
    saltos de mes incorrectos): la 1ra pendiente cae exactamente en
    nueva_fecha_base, la 2da un intervalo después, la 3ra dos intervalos
    después, etc. Los montos y estados de cada cuota no se alteran."""
    if not factura.cuotas:
        return
    pendientes = sorted(
        (c for c in factura.cuotas if c.estado != EstadoFactura.pagada),
        key=lambda c: c.numero_cuota,
    )
    for indice, cuota in enumerate(pendientes, start=1):
        cuota.fecha_vencimiento = _siguiente_vencimiento(nueva_fecha_base, indice, frecuencia)


def _generar_plan_cuotas(total: Decimal, fecha_base: date, numero_cuotas: int, frecuencia: str) -> List[Cuota]:
    """Reparte el total en cuotas iguales (con ajuste de redondeo en la última).
    Se usa tanto al emitir una factura nueva como al crear la factura consolidada
    de un reenganche.
    """
    n_cuotas = max(numero_cuotas, 1)
    monto_por_cuota = (total / n_cuotas).quantize(Decimal("0.01"))
    acumulado = Decimal("0")
    cuotas = []
    for i in range(1, n_cuotas + 1):
        monto = monto_por_cuota
        if i == n_cuotas:
            monto = total - acumulado
        acumulado += monto
        cuotas.append(Cuota(
            numero_cuota=i,
            fecha_vencimiento=_siguiente_vencimiento(fecha_base, i, frecuencia),
            monto_capital=monto,
            estado=EstadoFactura.pendiente,
        ))
    return cuotas


@router.get("", response_model=List[FacturaOut])
def listar_facturas(
    db: Session = Depends(get_db),
    cliente_id: Optional[int] = None,
    estado: Optional[str] = None,
    estado_mora: Optional[str] = None,
    q: Optional[str] = Query(None, description="Buscar por número de factura, nombre o documento del cliente"),
    fecha_desde: Optional[date] = None,
    fecha_hasta: Optional[date] = None,
):
    query = db.query(Factura).options(
        joinedload(Factura.items), joinedload(Factura.cuotas), joinedload(Factura.cliente), joinedload(Factura.pagos)
    )
    if q:
        like = f"%{q}%"
        query = query.join(Cliente).filter(
            (Factura.numero_factura.ilike(like))
            | (Cliente.razon_social.ilike(like))
            | (Cliente.numero_documento.ilike(like))
        )
    if cliente_id:
        query = query.filter(Factura.cliente_id == cliente_id)
    if estado:
        query = query.filter(Factura.estado == estado)
    if estado_mora:
        query = query.filter(Factura.estado_mora == estado_mora)
    if fecha_desde:
        query = query.filter(Factura.fecha_emision >= fecha_desde)
    if fecha_hasta:
        query = query.filter(Factura.fecha_emision <= fecha_hasta)

    facturas = query.order_by(Factura.fecha_emision.desc()).all()
    for f in facturas:
        actualizar_estado_mora_factura(f)
    db.commit()
    return facturas


@router.post("", response_model=FacturaOut, status_code=201)
def crear_factura(payload: FacturaCreate, db: Session = Depends(get_db)):
    cliente = db.query(Cliente).get(payload.cliente_id)
    if not cliente:
        raise HTTPException(404, "Cliente no encontrado")

    if payload.frecuencia_pago not in ("semanal", "quincenal", "mensual"):
        raise HTTPException(400, "Frecuencia inválida: usa semanal, quincenal o mensual")

    subtotal = Decimal("0")
    impuestos = Decimal("0")
    items_db: List[FacturaItem] = []

    for item in payload.items:
        cant = Decimal(str(item.cantidad))
        precio = Decimal(str(item.precio_unitario))
        pct_imp = Decimal(str(item.porcentaje_impuesto))

        subtotal_linea = (cant * precio).quantize(Decimal("0.01"))
        impuesto_linea = (subtotal_linea * pct_imp / 100).quantize(Decimal("0.01"))

        subtotal += subtotal_linea
        impuestos += impuesto_linea

        items_db.append(FacturaItem(
            descripcion=item.descripcion or settings.PRESTAMO_DESCRIPCION_DEFECTO,
            cantidad=cant,
            precio_unitario=precio,
            porcentaje_impuesto=pct_imp,
            subtotal_linea=subtotal_linea,
        ))

    descuento = Decimal(str(payload.descuento))

    tasa_interes = Decimal(str(payload.tasa_interes_prestamo)) if payload.tasa_interes_prestamo else Decimal("0")
    interes_prestamo = (subtotal * tasa_interes / 100).quantize(Decimal("0.01"))

    total = subtotal + impuestos + interes_prestamo - descuento

    factura = Factura(
        numero_factura=generar_numero_factura(db),
        cliente_id=cliente.id,
        fecha_emision=date.today(),
        fecha_vencimiento=payload.fecha_vencimiento,
        frecuencia_pago=payload.frecuencia_pago,
        subtotal=subtotal,
        impuestos=impuestos,
        descuento=descuento,
        tasa_interes_prestamo=payload.tasa_interes_prestamo,
        interes_prestamo=interes_prestamo,
        total=total,
        saldo_capital=total,
        estado=EstadoFactura.pendiente,
        notas=payload.notas,
        items=items_db,
    )

    factura.cuotas = _generar_plan_cuotas(
        total, payload.fecha_vencimiento, payload.numero_cuotas, payload.frecuencia_pago
    )

    db.add(factura)
    db.commit()
    db.refresh(factura)
    return factura


def _recalcular_totales(
    items_payload: List, descuento_val: float, tasa_interes_val: Optional[float]
):
    """Misma fórmula que crear_factura: recibe los ítems del payload y
    devuelve (subtotal, impuestos, interes_prestamo, total, items_db)."""
    subtotal = Decimal("0")
    impuestos = Decimal("0")
    items_db: List[FacturaItem] = []

    for item in items_payload:
        cant = Decimal(str(item.cantidad))
        precio = Decimal(str(item.precio_unitario))
        pct_imp = Decimal(str(item.porcentaje_impuesto))

        subtotal_linea = (cant * precio).quantize(Decimal("0.01"))
        impuesto_linea = (subtotal_linea * pct_imp / 100).quantize(Decimal("0.01"))

        subtotal += subtotal_linea
        impuestos += impuesto_linea

        items_db.append(FacturaItem(
            descripcion=item.descripcion or settings.PRESTAMO_DESCRIPCION_DEFECTO,
            cantidad=cant,
            precio_unitario=precio,
            porcentaje_impuesto=pct_imp,
            subtotal_linea=subtotal_linea,
        ))

    descuento = Decimal(str(descuento_val))
    tasa_interes = Decimal(str(tasa_interes_val)) if tasa_interes_val else Decimal("0")
    interes_prestamo = (subtotal * tasa_interes / 100).quantize(Decimal("0.01"))
    total = subtotal + impuestos + interes_prestamo - descuento

    return subtotal, impuestos, interes_prestamo, total, items_db


@router.put("/{factura_id}", response_model=FacturaOut)
def editar_factura(factura_id: int, payload: FacturaUpdate, db: Session = Depends(get_db)):
    factura = db.query(Factura).options(
        joinedload(Factura.items), joinedload(Factura.cuotas), joinedload(Factura.pagos)
    ).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")
    if factura.estado in (EstadoFactura.pagada, EstadoFactura.anulada):
        raise HTTPException(400, "No se puede editar una factura pagada o anulada")

    if payload.frecuencia_pago is not None:
        if payload.frecuencia_pago not in ("semanal", "quincenal", "mensual"):
            raise HTTPException(400, "Frecuencia inválida: usa semanal, quincenal o mensual")
        factura.frecuencia_pago = payload.frecuencia_pago
    if payload.notas is not None:
        factura.notas = payload.notas

    cambio_calendario = (
        (payload.fecha_vencimiento is not None and payload.fecha_vencimiento != factura.fecha_vencimiento)
        or (payload.frecuencia_pago is not None and payload.frecuencia_pago != factura.frecuencia_pago)
    )
    if payload.fecha_vencimiento is not None:
        factura.fecha_vencimiento = payload.fecha_vencimiento

    tiene_pagos = len(factura.pagos) > 0
    quiere_cambiar_montos = any(
        v is not None for v in (payload.items, payload.numero_cuotas, payload.descuento, payload.tasa_interes_prestamo)
    )

    if not quiere_cambiar_montos and cambio_calendario:
        # No se tocan montos ni cantidad de cuotas: solo se reancla el
        # calendario de las cuotas que aún faltan por pagar (ver docstring
        # de _recalcular_fechas_pendientes). Antes de este fix, forzar la
        # fecha aquí no tenía ningún efecto real porque solo se actualizaba
        # factura.fecha_vencimiento y nunca las fechas de cada cuota.
        _recalcular_fechas_pendientes(factura, factura.fecha_vencimiento, factura.frecuencia_pago)

    if quiere_cambiar_montos:
        capital_ya_pagado = sum((Decimal(p.monto_capital) for p in factura.pagos), Decimal("0"))

        items_payload = payload.items if payload.items is not None else [
            FacturaItemCreate(
                descripcion=it.descripcion, cantidad=float(it.cantidad),
                precio_unitario=float(it.precio_unitario), porcentaje_impuesto=float(it.porcentaje_impuesto),
            ) for it in factura.items
        ]
        descuento_val = payload.descuento if payload.descuento is not None else float(factura.descuento)
        tasa_val = (
            payload.tasa_interes_prestamo if payload.tasa_interes_prestamo is not None
            else (float(factura.tasa_interes_prestamo) if factura.tasa_interes_prestamo else None)
        )

        subtotal, impuestos, interes_prestamo, total, items_db = _recalcular_totales(
            items_payload, descuento_val, tasa_val
        )

        if tiene_pagos and total < capital_ya_pagado:
            raise HTTPException(
                400,
                f"No puedes dejar el monto corregido (RD${total}) por debajo de lo que ya se cobró "
                f"en esta factura (RD${capital_ya_pagado}). Sube el monto, o si fue un error grave, "
                "anula la factura y créala de nuevo.",
            )

        factura.items = items_db
        factura.subtotal = subtotal
        factura.impuestos = impuestos
        factura.descuento = Decimal(str(descuento_val))
        factura.tasa_interes_prestamo = tasa_val
        factura.interes_prestamo = interes_prestamo
        factura.total = total

        n_cuotas = payload.numero_cuotas if payload.numero_cuotas is not None else factura.total_cuotas
        nuevas_cuotas = _generar_plan_cuotas(
            total, factura.fecha_vencimiento, n_cuotas, factura.frecuencia_pago
        )

        if tiene_pagos and capital_ya_pagado > 0:
            CENTAVO = Decimal("0.01")
            restante = capital_ya_pagado
            for c in sorted(nuevas_cuotas, key=lambda c: c.numero_cuota):
                if restante <= 0:
                    break
                capital_cuota = Decimal(c.monto_capital).quantize(CENTAVO)
                aplicado = min(restante, capital_cuota)
                c.monto_pagado = aplicado
                c.estado = EstadoFactura.pagada if aplicado >= capital_cuota else EstadoFactura.parcial
                restante -= aplicado

        factura.cuotas = nuevas_cuotas
        factura.saldo_capital = total - capital_ya_pagado
        if factura.saldo_capital <= 0:
            factura.saldo_capital = Decimal("0")
            factura.estado = EstadoFactura.pagada
        elif tiene_pagos:
            factura.estado = EstadoFactura.parcial

        actualizar_estado_mora_factura(factura)

    db.commit()
    db.refresh(factura)
    return factura


@router.patch("/{factura_id}/cuota-manual", response_model=FacturaOut)
def ajustar_cuota_manual(factura_id: int, payload: CuotaManualUpdate, db: Session = Depends(get_db)):
    """Forzar (o quitar) el número de cuota mostrado a mano, para cuando un
    cliente pagó por fuera del sistema y hay que ajustar el contador sin
    tocar los pagos reales ni los montos. No borra ni recalcula nada de la
    factura — solo cambia qué número se MUESTRA en panel, PDF, JPG y
    WhatsApp (los tres leen del mismo campo, así que quedan sincronizados
    de inmediato). El flujo automático (1 pago = avanza 1 cuota) sigue
    funcionando exactamente igual por debajo; payload.cuota=null lo
    reactiva en cualquier momento."""
    factura = db.query(Factura).options(
        joinedload(Factura.items), joinedload(Factura.cuotas), joinedload(Factura.pagos)
    ).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")
    if factura.estado == EstadoFactura.anulada:
        raise HTTPException(400, "No se puede editar la cuota de una factura anulada")

    if payload.cuota is not None:
        if payload.cuota < 0 or payload.cuota > factura.total_cuotas:
            raise HTTPException(
                400,
                f"El número de cuota debe estar entre 0 y {factura.total_cuotas} (el total de cuotas de esta factura)",
            )

    # Aislamiento total: numero_factura es sagrado. Se guarda ANTES de
    # tocar nada, y se compara DESPUÉS del commit — si por cualquier motivo
    # llegara a cambiar (bug futuro, migración de datos, lo que sea), esto
    # revienta con un error 500 en vez de dejar pasar en silencio un
    # número de factura alterado. Este endpoint solo debe escribir UN
    # campo: cuota_manual_override.
    numero_factura_antes = factura.numero_factura
    factura.cuota_manual_override = payload.cuota

    db.commit()
    db.refresh(factura)

    if factura.numero_factura != numero_factura_antes:
        db.rollback()
        raise HTTPException(
            500,
            "Se bloqueó el ajuste de cuota: se detectó un intento de alterar el número de factura, "
            "lo cual nunca debe pasar. No se guardó ningún cambio.",
        )

    return factura


@router.get("/{factura_id}", response_model=FacturaOut)
def obtener_factura(factura_id: int, db: Session = Depends(get_db)):
    factura = db.query(Factura).options(
        joinedload(Factura.items), joinedload(Factura.cuotas), joinedload(Factura.pagos)
    ).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")
    actualizar_estado_mora_factura(factura)
    db.commit()
    return factura


@router.get("/{factura_id}/pdf")
def descargar_pdf_factura(factura_id: int, db: Session = Depends(get_db)):
    import os
    factura = db.query(Factura).options(
        joinedload(Factura.items), joinedload(Factura.cuotas), joinedload(Factura.cliente), joinedload(Factura.pagos)
    ).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")

    ruta_logo = os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "static", "img", "logo-rym.jpeg")
    ruta_logo = ruta_logo if os.path.exists(ruta_logo) else None

    pdf_bytes = generar_pdf_factura(factura, nombre_empresa=settings.EMPRESA_NOMBRE, logo_path=ruta_logo)
    nombre_archivo = f"factura_{factura.numero_factura}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{nombre_archivo}"'},
    )


@router.get("/{factura_id}/reenganche/elegibilidad", response_model=ReenganeElegibilidadOut)
def elegibilidad_reenganche(factura_id: int, db: Session = Depends(get_db)):
    factura = db.query(Factura).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")

    actualizar_estado_mora_factura(factura)
    db.commit()

    return calcular_elegibilidad(factura)


@router.post("/{factura_id}/reenganche", response_model=FacturaOut, status_code=201)
def reenganchar_factura(factura_id: int, payload: ReenganeCreate, db: Session = Depends(get_db)):
    factura = db.query(Factura).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")

    if payload.frecuencia_pago and payload.frecuencia_pago not in ("semanal", "quincenal", "mensual"):
        raise HTTPException(400, "Frecuencia inválida: usa semanal, quincenal o mensual")

    nueva_factura = ejecutar_reenganche(
        db=db,
        factura=factura,
        monto_adicional=Decimal(str(payload.monto_adicional)),
        fecha_vencimiento=payload.fecha_vencimiento,
        numero_cuotas=payload.numero_cuotas,
        frecuencia_pago=payload.frecuencia_pago,
        descripcion=payload.descripcion,
        generar_plan_cuotas_fn=_generar_plan_cuotas,
    )

    db.commit()
    db.refresh(nueva_factura)
    return nueva_factura


@router.post("/{factura_id}/anular", response_model=FacturaOut, dependencies=[Depends(requerir_admin)])
def anular_factura(factura_id: int, db: Session = Depends(get_db)):
    factura = db.query(Factura).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")
    if factura.estado == EstadoFactura.pagada:
        raise HTTPException(400, "No se puede anular una factura ya pagada")
    factura.estado = EstadoFactura.anulada
    db.commit()
    db.refresh(factura)
    return factura


@router.delete("/{factura_id}", status_code=204, dependencies=[Depends(requerir_admin)])
def eliminar_factura(factura_id: int, db: Session = Depends(get_db)):
    """Borra una factura y todo lo que le pertenece (cuotas, ítems, pagos,
    recibos). Es IRREVERSIBLE. Pensado para que el usuario limpie a mano
    facturas ya pagadas/cerradas o de prueba — el sistema NUNCA borra nada
    solo, esto es siempre una decisión manual desde el botón "Eliminar".
    No toca al cliente: el cliente y sus demás facturas siguen intactos."""
    factura = db.query(Factura).get(factura_id)
    if not factura:
        raise HTTPException(404, "Factura no encontrada")

    pago_ids = [p.id for p in db.query(Pago.id).filter(Pago.factura_id == factura_id)]
    if pago_ids:
        db.query(Recibo).filter(Recibo.pago_id.in_(pago_ids)).delete(synchronize_session=False)
        db.query(Pago).filter(Pago.id.in_(pago_ids)).delete(synchronize_session=False)

    db.query(Factura).filter(Factura.factura_origen_id == factura_id).update(
        {"factura_origen_id": None}, synchronize_session=False
    )

    db.query(Cuota).filter(Cuota.factura_id == factura_id).delete(synchronize_session=False)
    db.query(FacturaItem).filter(FacturaItem.factura_id == factura_id).delete(synchronize_session=False)

    db.delete(factura)
    db.commit()
